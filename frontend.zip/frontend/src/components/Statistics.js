import React, { useEffect, useState } from "react";
import axios from "axios";

const Statistics = ({ month }) => {
  const [statistics, setStatistics] = useState({ totalSaleAmount: 0, soldItems: 0, notSoldItems: 0 });

  useEffect(() => {
    axios
      .get(`http://localhost:5000/api/transactions/statistics?month=${month}`)
      .then((res) => setStatistics(res.data))
      .catch((err) => console.error("Error fetching statistics", err));
  }, [month]);

  return (
    <div className="statistics">
      <h2>Statistics for {month}</h2>
      <p>Total Sale Amount: ${statistics.totalSaleAmount.toFixed(2)}</p>
      <p>Total Sold Items: {statistics.soldItems}</p>
      <p>Total Not Sold Items: {statistics.notSoldItems}</p>
    </div>
  );
};

export default Statistics;
