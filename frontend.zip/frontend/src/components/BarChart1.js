import React, { useEffect, useState } from "react";
import axios from "axios";
import { Bar } from "react-chartjs-2";
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend } from 'chart.js';

// Register the necessary components
ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

const BarChart1 = ({ month }) => {
  const [barData, setBarData] = useState([]);

  useEffect(() => {
    axios
      .get(`http://localhost:5000/api/transactions/bar-chart?month=${month}`)
      .then((res) => setBarData(res.data))
      .catch((err) => console.error("Error fetching bar chart data", err));
  }, [month]);

  const chartData = {
    labels: barData.map((data) => `${data._id}`),
    datasets: [
      {
        label: "Number of Items",
        data: barData.map((data) => data.count),
        backgroundColor: "rgba(75, 192, 192, 0.6)",
      },
    ],
  };

  return (
    <div className="bar-chart">
      <h2>Bar Chart for {month}</h2>
      <Bar data={chartData} />
    </div>
  );
};

export default BarChart1;
