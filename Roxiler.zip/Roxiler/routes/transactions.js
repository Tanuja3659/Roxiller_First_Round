const express = require("express");
const {
  initializeDB,
  getTransactions,
  getCombinedData,
  getStatistics,
  getBarChart,
  getPieChart,
} = require("../controllers/transactionController");


const router = express.Router();

router.get("/initialize", initializeDB);
router.get("/list", getTransactions);
router.get("/combined", getCombinedData);

router.get("/statistics", async (req, res) => {
  const { month } = req.query;
  try {
    if (!month) return res.status(400).send("Month parameter is required");

    const statistics = await getStatistics(month);
    res.status(200).json(statistics);
  } catch (error) {
    console.error("Error in fetching statistics:", error.message);
    res.status(500).send(`Server Error: ${error.message}`);
  }
});

router.get("/bar-chart", async (req, res) => {
  const { month } = req.query;
  try {
    if (!month) return res.status(400).send("Month parameter is required");

    const barChartData = await getBarChart(month);
    res.status(200).json(barChartData);
  } catch (error) {
    console.error("Error in fetching bar chart data:", error.message);
    res.status(500).send(`Server Error: ${error.message}`);
  }
});

router.get("/pie-chart", async (req, res) => {
  const { month } = req.query;
  try {
    if (!month) return res.status(400).send("Month parameter is required");

    const pieChartData = await getPieChart(month);
    res.status(200).json(pieChartData);
  } catch (error) {
    console.error("Error in fetching pie chart data:", error.message);
    res.status(500).send(`Server Error: ${error.message}`);
  }
});

module.exports = router;
