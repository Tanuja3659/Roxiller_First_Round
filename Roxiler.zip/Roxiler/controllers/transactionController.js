const axios = require("axios");
const Transaction = require("../models/Transaction");

// API to Initialize the Database with Seed Data
exports.initializeDB = async (req, res) => {
  try {
    const response = await axios.get("https://s3.amazonaws.com/roxiler.com/product_transaction.json");
    const transactions = response.data;
    await Transaction.insertMany(transactions);
    res.status(200).send("Database initialized successfully with seed data");
  } catch (error) {
    console.error("Error in initializing DB:", error);
    res.status(500).send("Server Error");
  }
};

// Function to get transactions
exports.getTransactions = async (req, res) => {
  const { page = 1, perPage = 10, search = "", month } = req.query;

  try {
    const monthNumber = month ? new Date(`${month} 1, 2000`).getMonth() + 1 : null;

    const query = {
      ...(monthNumber && { $expr: { $eq: [{ $month: "$dateOfSale" }, monthNumber] } }),
      $or: [
        { title: { $regex: search, $options: "i" } },
        { description: { $regex: search, $options: "i" } },
        ...(search && !isNaN(search) ? [{ price: parseFloat(search) }] : []),
      ],
    };

    const skip = (page - 1) * perPage;
    const transactions = await Transaction.find(query).skip(skip).limit(parseInt(perPage));
    const total = await Transaction.countDocuments(query);

    res.status(200).json({
      page,
      perPage,
      total,
      transactions,
    });
  } catch (error) {
    console.error("Error in fetching transactions:", error);
    res.status(500).send("Server Error");
  }
};

// Helper functions for statistics, bar chart, and pie chart
exports.getStatistics = async (month) => {
  const monthNumber = new Date(`${month} 1, 2000`).getMonth() + 1;

  const sales = await Transaction.aggregate([
    { $match: { $expr: { $eq: [{ $month: "$dateOfSale" }, monthNumber] } } },
    {
      $group: {
        _id: null,
        totalSaleAmount: { $sum: "$price" },
        soldItems: { $sum: { $cond: ["$sold", 1, 0] } },
        notSoldItems: { $sum: { $cond: ["$sold", 0, 1] } },
      },
    },
  ]);

  return sales.length === 0 ? { totalSaleAmount: 0, soldItems: 0, notSoldItems: 0 } : sales[0];
};

exports.getBarChart = async (month) => {
  const monthNumber = new Date(`${month} 1, 2000`).getMonth() + 1;

  return await Transaction.aggregate([
    { $match: { $expr: { $eq: [{ $month: "$dateOfSale" }, monthNumber] } } },
    {
      $bucket: {
        groupBy: "$price",
        boundaries: [0, 100, 200, 300, 400, 500, 600, 700, 800, 900, Infinity],
        default: "901-above",
        output: { count: { $sum: 1 } },
      },
    },
  ]);
};

exports.getPieChart = async (month) => {
  const monthNumber = new Date(`${month} 1, 2000`).getMonth() + 1;

  return await Transaction.aggregate([
    { $match: { $expr: { $eq: [{ $month: "$dateOfSale" }, monthNumber] } } },
    { $group: { _id: "$category", count: { $sum: 1 } } },
  ]);
};

// Combined Data API
exports.getCombinedData = async (req, res) => {
  const { month } = req.query;

  try {
    const [statistics, barChart, pieChart] = await Promise.all([
      getStatistics(month),
      getBarChart(month),
      getPieChart(month),
    ]);

    res.status(200).json({ statistics, barChart, pieChart });
  } catch (error) {
    console.error("Error in fetching combined data:", error);
    res.status(500).send("Server Error");
  }
};

// Remove this line since `getTransactions` is already exported above
// exports.getTransactions = getTransactions; 
